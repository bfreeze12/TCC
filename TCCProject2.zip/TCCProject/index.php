<?php
require_once 'config.php';

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $name = $conn->real_escape_string($_POST['itemName']);
                $category = $conn->real_escape_string($_POST['itemCategory']);
                $quantity = (int)$_POST['itemQuantity'];
                $price = (float)$_POST['itemPrice'];

                $sql = "INSERT INTO menu_items (name, category, quantity, price) 
                        VALUES ('$name', '$category', $quantity, $price)";
                
                if ($conn->query($sql)) {
                    echo "<script>alert('Item added successfully!');</script>";
                } else {
                    echo "<script>alert('Error adding item: " . $conn->error . "');</script>";
                }
                break;

            case 'edit':
                $id = (int)$_POST['itemId'];
                $name = $conn->real_escape_string($_POST['itemName']);
                $category = $conn->real_escape_string($_POST['itemCategory']);
                $quantity = (int)$_POST['itemQuantity'];
                $price = (float)$_POST['itemPrice'];

                $sql = "UPDATE menu_items 
                        SET name='$name', category='$category', 
                            quantity=$quantity, price=$price 
                        WHERE id=$id";
                
                if ($conn->query($sql)) {
                    echo "<script>alert('Item updated successfully!');</script>";
                } else {
                    echo "<script>alert('Error updating item: " . $conn->error . "');</script>";
                }
                break;

            case 'delete':
                $id = (int)$_POST['itemId'];
                $sql = "DELETE FROM menu_items WHERE id=$id";
                
                if ($conn->query($sql)) {
                    echo "<script>alert('Item deleted successfully!');</script>";
                } else {
                    echo "<script>alert('Error deleting item: " . $conn->error . "');</script>";
                }
                break;
        }
    }
}

// Function to get all menu items
function getMenuItems($conn) {
    $items = array();
    $sql = "SELECT * FROM menu_items ORDER BY id DESC";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
    }
    return $items;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Café Menu Management</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <!-- ... existing navbar code ... -->
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero-section">
        <!-- ... existing hero section code ... -->
    </section>

    <!-- Menu Display Section -->
    <section id="menuDisplay" class="section" style="display: none;">
        <div class="menu-container">
            <h2>Our Menu Items</h2>
            <table class="menu-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $menuItems = getMenuItems($conn);
                    if (empty($menuItems)) {
                        echo "<tr><td colspan='6' style='text-align: center;'>No items available</td></tr>";
                    } else {
                        foreach($menuItems as $item) {
                            echo "<tr>";
                            echo "<td>{$item['id']}</td>";
                            echo "<td>{$item['name']}</td>";
                            echo "<td>{$item['category']}</td>";
                            echo "<td>{$item['quantity']}</td>";
                            echo "<td>\${$item['price']}</td>";
                            echo "<td class='action-buttons'>";
                            echo "<button onclick='editItem({$item['id']})' class='edit-button'>Edit</button>";
                            echo "<button onclick='deleteItem({$item['id']})' class='delete-button'>Delete</button>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </section>

    <!-- Add Item Section -->
    <section id="addItem" class="section" style="display: none;">
        <div class="form-container">
            <h2>Add New Menu Item</h2>
            <form id="addItemForm" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="form-group">
                    <label for="itemName">Item Name</label>
                    <input type="text" id="itemName" name="itemName" required>
                </div>
                <div class="form-group">
                    <label for="itemCategory">Category</label>
                    <input type="text" id="itemCategory" name="itemCategory" required>
                </div>
                <div class="form-group">
                    <label for="itemQuantity">Quantity</label>
                    <input type="number" id="itemQuantity" name="itemQuantity" required>
                </div>
                <div class="form-group">
                    <label for="itemPrice">Price ($)</label>
                    <input type="number" step="0.01" id="itemPrice" name="itemPrice" required>
                </div>
                <button type="submit" class="submit-button">Add Item</button>
            </form>
        </div>
    </section>

    <!-- About and Contact sections remain the same -->

    <footer>
        <p>© 2024 Café Menu Management System. All rights reserved.</p>
    </footer>

    <script>
    function editItem(id) {
        // Get item details via AJAX and populate form
        fetch(`get_item.php?id=${id}`)
            .then(response => response.json())
            .then(item => {
                document.getElementById('itemName').value = item.name;
                document.getElementById('itemCategory').value = item.category;
                document.getElementById('itemQuantity').value = item.quantity;
                document.getElementById('itemPrice').value = item.price;
                
                // Change form action to edit
                const form = document.getElementById('addItemForm');
                form.querySelector('input[name="action"]').value = 'edit';
                form.insertAdjacentHTML('beforeend', 
                    `<input type="hidden" name="itemId" value="${id}">`);
                
                showSection('addItem');
            });
    }

    function deleteItem(id) {
        if (confirm('Are you sure you want to delete this item?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="itemId" value="${id}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
    }

    // ... rest of your existing JavaScript code ...
    </script>
</body>
</html>
