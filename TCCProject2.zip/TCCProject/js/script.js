// Store menu items in localStorage
let menuItems = JSON.parse(localStorage.getItem('menuItems')) || [];

// Function to show/hide sections
function showSection(sectionId) {
    // Hide all sections first
    const sections = ['home', 'menuDisplay', 'addItem', 'about', 'contact'];
    sections.forEach(section => {
        const element = document.getElementById(section);
        if (element) {
            element.style.display = 'none';
        }
    });

    // Show the selected section
    const selectedSection = document.getElementById(sectionId);
    if (selectedSection) {
        selectedSection.style.display = 'block';
        
        // Scroll to top when changing sections
        window.scrollTo(0, 0);
        
        // If showing menu display, refresh the table
        if (sectionId === 'menuDisplay') {
            displayMenuItems();
        }
    }
}

// Function to display menu items
function displayMenuItems() {
    const tableBody = document.getElementById('menuTableBody');
    if (!tableBody) return;

    // Clear the table body
    tableBody.innerHTML = '';
    
    // Get latest items from localStorage
    const items = JSON.parse(localStorage.getItem('menuItems')) || [];
    
    if (items.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="6" style="text-align: center; padding: 20px;">
                No items available. Please add some items.
            </td>
        `;
        tableBody.appendChild(row);
        return;
    }

    items.forEach((item, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${item.name}</td>
            <td>${item.category}</td>
            <td>${item.quantity}</td>
            <td>$${parseFloat(item.price).toFixed(2)}</td>
            <td>
                <button onclick="editItem(${index})" class="edit-button">Edit</button>
                <button onclick="deleteItem(${index})" class="delete-button">Delete</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// Function to add new item
function addNewItem(event) {
    event.preventDefault();
    
    const newItem = {
        name: document.getElementById('itemName').value,
        category: document.getElementById('itemCategory').value,
        quantity: parseInt(document.getElementById('itemQuantity').value),
        price: parseFloat(document.getElementById('itemPrice').value)
    };

    // Get current items from localStorage
    let items = JSON.parse(localStorage.getItem('menuItems')) || [];
    
    // Add new item
    items.push(newItem);
    
    // Save back to localStorage
    localStorage.setItem('menuItems', JSON.stringify(items));
    
    // Update menuItems array
    menuItems = items;
    
    // Reset form
    document.getElementById('addItemForm').reset();
    
    // Show success message
    alert('Item added successfully!');
    
    // Switch to menu display
    showSection('menuDisplay');
}

// Function to delete item
function deleteItem(index) {
    if (confirm('Are you sure you want to delete this item?')) {
        // Get current items
        let items = JSON.parse(localStorage.getItem('menuItems')) || [];
        
        // Remove item
        items.splice(index, 1);
        
        // Save back to localStorage
        localStorage.setItem('menuItems', JSON.stringify(items));
        
        // Update menuItems array
        menuItems = items;
        
        // Refresh display
        displayMenuItems();
    }
}

// Function to edit item
function editItem(index) {
    // Get current items
    let items = JSON.parse(localStorage.getItem('menuItems')) || [];
    const item = items[index];
    
    // Fill form with item data
    document.getElementById('itemName').value = item.name;
    document.getElementById('itemCategory').value = item.category;
    document.getElementById('itemQuantity').value = item.quantity;
    document.getElementById('itemPrice').value = item.price;
    
    // Change form submission handler
    const form = document.getElementById('addItemForm');
    form.onsubmit = function(e) {
        e.preventDefault();
        
        // Update item
        items[index] = {
            name: document.getElementById('itemName').value,
            category: document.getElementById('itemCategory').value,
            quantity: parseInt(document.getElementById('itemQuantity').value),
            price: parseFloat(document.getElementById('itemPrice').value)
        };
        
        // Save to localStorage
        localStorage.setItem('menuItems', JSON.stringify(items));
        
        // Update menuItems array
        menuItems = items;
        
        // Reset form
        form.reset();
        form.onsubmit = addNewItem; // Reset to normal add function
        
        // Show success message
        alert('Item updated successfully!');
        
        // Switch to menu display
        showSection('menuDisplay');
    };
    
    // Show add item form
    showSection('addItem');
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Load items from localStorage
    menuItems = JSON.parse(localStorage.getItem('menuItems')) || [];
    
    // Add form submit handler
    const form = document.getElementById('addItemForm');
    if (form) {
        form.onsubmit = addNewItem;
    }
    
    // Show home section by default
    showSection('home');
});

// Handle contact form submission
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Thank you for your message! We will get back to you soon.');
        this.reset();
    });
}
